<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

 use App\Controllers\Accueil;
 $routes->get('/', [Accueil::class,'afficher']);


 use App\Controllers\Connexion;

 // Route pour afficher la page de connexion (GET)
 $routes->get('afficher/connexion', [Connexion::class, 'affiche']);
 
 // Route pour soumettre le formulaire de connexion (POST)
 $routes->post('afficher/connexion', [Connexion::class, 'affiche']);
 


 use App\Controllers\Creation;

 // Route pour afficher la page de connexion (GET)
 $routes->get('afficher/creation', [Creation::class, 'affiche']);
 $routes->post('afficher/creation', [Creation::class, 'affiche']);
 
 $routes->get('afficher/ajoute_invite', [Creation::class, 'ajoute_invite']);
 $routes->post('afficher/ajoute_invite', [Creation::class, 'ajoute_invite']);


 use App\Controllers\Activite;
 $routes->get('afficher/activite', [Activite::class,'afficher']);
 $routes->get('afficher/retour', [Activite::class,'retour']);

 $routes->get('activite/ajoute', [Activite::class,'ajoute']);
 $routes->post('activite/ajoute', [Activite::class, 'ajoute']);



 $routes->get('activite/deconnecter', [Activite::class, 'deconnecter']);

 use App\Controllers\Statistique;
 $routes->get('afficher/state', [Statistique::class,'state']);