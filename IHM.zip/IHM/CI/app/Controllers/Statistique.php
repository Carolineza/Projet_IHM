<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Statistique extends BaseController
{

    public function state() {
     

        $session=session();
        if ($session->has('user')){
    
         $model = model(Db_model::class);

         $email = $session->get('user');
         $id = $model->get_role($email);  // Renvoie l'ID de l'utilisateur connecté
         $session->set('id', $id);
         $data = [
            'semaine' => $model->get_semaine($id),
            // Jours de la semaine 
            'lundi' => $model->get_jour($id, 2),
            'mardi' => $model->get_jour($id, 3),
            'mercredi' => $model->get_jour($id, 4),
            'jeudi' => $model->get_jour($id, 5),
            'vendredi' => $model->get_jour($id, 6),
            'samedi' => $model->get_jour($id, 7),
            'dimanche' => $model->get_jour($id, 1),
        ];
         return  view('statistiques/statistiques.php',$data);
        }else{
           return redirect()->to(base_url('/'));
        }
         
    }
    

}

?>