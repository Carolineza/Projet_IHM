<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Statistique extends BaseController
{

    public function state() {
     

        $session=session();
        if ($session->has('user')){
    
         $model = model(Db_model::class);
    
         return  view('statistiques/statistiques.php');
        }else{
           return redirect()->to(base_url('/'));
        }
         
    }
    

}

?>