<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Activite extends BaseController
{

public function afficher() {
     

    $session=session();
    if ($session->has('user')){

     $model = model(Db_model::class);

     $pseudo=$model->get_pseudo($session->get('user'));
     $data['new'] = $model->get_all_actualites($session->get('user'));
     $data['pseudo']=$pseudo;
     return view('activite/activite.php',$data);
    }else{
       return redirect()->to(base_url('/'));
    }
     
}

public function retour() {
     

    $session=session();
    if ($session->has('user')){

     $model = model(Db_model::class);

     return  view('activite/premiere_page.php');
    }else{
       return redirect()->to(base_url('/'));
    }
     
}

public function ajoute() {
     

    $session=session();
    if ($session->has('user')){

     $model = model(Db_model::class);

     return  view('activite/ajoute_activite.php');
    }else{
       return redirect()->to(base_url('/'));
    }
     
}

public function deconnecter(){
$session=session();
$session->destroy();
 return redirect()->to(base_url('/'));
}


}

?>