<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;

class Connexion extends BaseController
{
     public function __construct()
    {
        helper('form');
        $this->model = model(Db_model::class);
       
    }

    public function affiche() {
        
        $model = model(Db_model::class);
        $method = $this->request->getMethod(true);

        if ($method === "POST") {
            

              $messages = [
               'mdp.min_length' => 'Le mot de passe doit contenir au moins 8 caractères.',
              ];

            if (! $this->validate([
               'email' => 'required|max_length[255]|min_length[2]',
               'password' => 'required|max_length[255]|min_length[8]' ]))
               {
                        // La validation du formulaire a échoué, retour au formulaire !
                $data['erreur'] = $messages;
                return view('connexion/connexion.php',$data);
               }else{
                    $email = $this->request->getPost('email');
                    $password = $this->request->getPost('password');

                    if ($model->connect_compte($email, $password) == true) {
                      // Success: set session and redirect
                      $session = session();
                      $session->set('user', $email);
                      return redirect()->to(base_url('afficher/activite'));
                  } else {
                      // Failed authentication: set an error message
                      $data['alert'] = "L'email ou le mot de passe est incorrect.";
                      return view('connexion/connexion.php',$data); // Replace 'your_view_name' with your view file name
                  }
               }

            // Exemple de redirection vers la page d'accueil après la connexion
            // Assurez-vous que l'URL générée est correcte
            
        }

        // Affichage de la vue pour GET
        return view('connexion/connexion.php');
    }
}
?>
