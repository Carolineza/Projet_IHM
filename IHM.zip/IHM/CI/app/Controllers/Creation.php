<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;

class Creation extends BaseController
{
     public function __construct()
    {
        helper('form');
        $this->model = model(Db_model::class);
       
    }

    public function affiche() {
        $model = model(Db_model::class);
        $method = $this->request->getMethod(true);

        if ($method === "POST") {
            $email = $this->request->getPost('email');
            $password = $this->request->getPost('password');
            $password_co = $this->request->getPost('confirm-password');
        
            // Initialiser un tableau d'erreurs vide
            $erreurs = [];
        
            // Définir les règles de validation et les messages d'erreur personnalisés
            $validationRules = [
                'username' => [
                    'rules' => 'required',
                    'errors' => [
                        'required' => 'Le nom d\'utilisateur est requis.'
                    ]
                ],
                'email' => [
                    'rules' => 'required|valid_email',
                    'errors' => [
                        'required' => 'L\'email est requis.',
                        'valid_email' => 'Veuillez entrer une adresse email valide.'
                    ]
                ],
                'password' => [
                    'rules' => 'required|max_length[255]|min_length[8]',
                    'errors' => [
                        'required' => 'Le mot de passe est requis.',
                        'max_length' => 'Le mot de passe ne doit pas dépasser 255 caractères.',
                        'min_length' => 'Le mot de passe doit contenir au moins 8 caractères.'
                    ]
                ],
                'confirm-password' => [
                    'rules' => 'required|matches[password]',
                    'errors' => [
                        'required' => 'Veuillez confirmer votre mot de passe.',
                        'matches' => 'Les mots de passe ne correspondent pas.'
                    ]
                ]
            ];
        
            // Validation des champs
            if (! $this->validate($validationRules)) {
                // Stocker les erreurs spécifiques pour chaque champ
                if ($this->validator->hasError('username')) {
                    $erreurs['username'] = $this->validator->getError('username');
                }
                if ($this->validator->hasError('email')) {
                    $erreurs['email'] = $this->validator->getError('email');
                }
                if ($this->validator->hasError('password')) {
                    $erreurs['password'] = $this->validator->getError('password');
                }
                if ($this->validator->hasError('confirm-password')) {
                    $erreurs['confirm-password'] = $this->validator->getError('confirm-password');
                }
        
                // Passer les erreurs à la vue
                $data['erreurs'] = $erreurs;
                return view('creation/creation_compte.php', $data);
            }else {
                $email = $this->request->getPost('email');
                $password = $this->request->getPost('password');
                $u = $this->request->getPost('username'); // Assurez-vous que vous avez récupéré le nom d'utilisateur

                // Vérification si les données sont présentes
                if (empty($email) || empty($password) || empty($u)) {
                    session()->setFlashdata('error_message', 'Tous les champs sont obligatoires.');
                    return redirect()->to('creation/creation_compte'); // Redirige vers la page de création de compte
                }

                // Appel à la méthode inscrire_utilisateur
                $result = $model->inscrire_utilisateur($u, $email, $password);

                if ($result === true) {
                    // Ajouter un message de succès à la session
                    session()->setFlashdata('success_message', 'Votre inscription a été réussie. Vous pouvez maintenant vous connecter.');

                    // Rediriger vers la page de connexion ou une autre page après l'inscription
                    return view('creation/creation_compte.php'); // Redirige vers la page de connexion ou la page appropriée après l'inscription
                } else {
                    // Ajouter un message d'erreur à la session avec le message retourné par inscrire_utilisateur
                    session()->setFlashdata('error_message', $result);

                    // Rediriger vers la page de création de compte avec un message d'erreur
                    return view('creation/creation_compte.php'); // Redirige vers la page de création de compte
                }




            }
        
           
        }
        
    
        return view('creation/creation_compte.php');   
    }




    public function ajoute_invite() {
        $session = session();
    
        // Vérifie si l'utilisateur est connecté
        if (!$session->has('user')) {
            return redirect()->to(base_url('/'))->with('error_message', 'Vous devez être connecté pour inviter.');
        }
    
        $model = model(Db_model::class);
        $email = $session->get('user');
        $id = $model->get_role($email);  // Renvoie l'ID de l'utilisateur connecté
        $session->set('id', $id);
    
        $data = [
            'abonne' => $model->get_abonne($id),
            'cible' => $model->get_abomment($id),
            'invites' => $model->get_inviteur($id)
        ];
    
        // Vérifie la méthode POST
        if ($this->request->getMethod(true) === "POST") {
            $friendIdentifier = $this->request->getPost('search-friends');
            
            if (empty($friendIdentifier)) {
                $session->setFlashdata('error_message', 'Le champ d\'invitation est requis.');
                return view('activite/premiere_page', $data);
            }
    
            $friendId = $model->get_role($friendIdentifier);
    
            if ($friendId && $model->is_valid_friend($id, $friendId)) {
                
                $session->setFlashdata('success_message', 'Invitation envoyée avec succès !');
            } else {
                $session->setFlashdata('error_message', 'Ami introuvable ou déjà invité.');
            }
        }
    
        // Affiche la vue de la première page
        return view('activite/premiere_page', $data);
    }


    public function ajoute_abonnes($mot) {
        $session = session();
    
        // Vérifie si l'utilisateur est connecté
        if (!$session->has('user')) {
            return redirect()->to(base_url('/'))->with('error_message', 'Vous devez être connecté pour inviter.');
        }
    
        $model = model(Db_model::class);
        $email = $session->get('user');
        $id = $model->get_role($email);  // Renvoie l'ID de l'utilisateur connecté
        $session->set('id', $id);
    
        $data = [
            'abonne' => $model->get_abonne($id),
            'cible' => $model->get_abomment($id),
            'invites' => $model->get_inviteur($id)
        ];
    
        if ($mot == "")
        {
        // Affiche la vue de la première page
        return view('activite/premiere_page', $data);
        }else{
            $friendId = $model->get_role($mot);

            $model->is_a($id, $friendId);
            return view('activite/premiere_page', $data);
        }
        
    }


    public function supprime_abonnes($mot) {
        $session = session();
    
        // Vérifie si l'utilisateur est connecté
        if (!$session->has('user')) {
            return redirect()->to(base_url('/'))->with('error_message', 'Vous devez être connecté pour inviter.');
        }
    
        $model = model(Db_model::class);
        $email = $session->get('user');
        $id = $model->get_role($email);  // Renvoie l'ID de l'utilisateur connecté
        $session->set('id', $id);
    
        $data = [
            'abonne' => $model->get_abonne($id),
            'cible' => $model->get_abomment($id),
            'invites' => $model->get_inviteur($id)
        ];
    
        if ($mot == "")
        {
        // Affiche la vue de la première page
        return view('activite/premiere_page', $data);
        }else{
            $friendId = $model->get_role($mot);

            $model->is_r($id, $friendId);
            return view('activite/premiere_page', $data);
        }
        
    }



    
    
    
}
?>
