<?php
namespace App\Models;
use CodeIgniter\Model;


class Db_model extends Model
{
    protected $db;
    public function __construct()
    {
    $this->db = db_connect(); //charger la base de données
    // ou
    // $this->db = \Config\Database::connect();
    }
    

    public function connect_compte($u, $p)
{
    // Adaptation de la requête à la nouvelle structure de la table
    $sql = ("SELECT `cpt_login`, `cpt_mot_passe` FROM `t_compte_cpt` WHERE `cpt_etat` = 'A' AND `cpt_login` = '" . $u . "' AND `cpt_mot_passe` = '" . $p . "';");
    
    $resultat = $this->db->query($sql);
    
    if ($resultat->getNumRows() > 0) {
        return true;
    } else {
        return false;
    }
}


public function inscrire_utilisateur($u, $email, $p)
{
    // Utilisation d'une requête préparée pour éviter les injections SQL
    $mail = htmlspecialchars(addslashes($email));
    $pseudo = htmlspecialchars(addslashes($u));
    $mot = htmlspecialchars(addslashes($p));

    // Vérifier si l'email ou le pseudo existent déjà
    $check_email = $this->db->query("SELECT COUNT(*) as count FROM t_compte_cpt WHERE cpt_login = '$mail'")->getRow();
    $check_pseudo = $this->db->query("SELECT COUNT(*) as count FROM t_compte_cpt WHERE cpt_pseudo = '$pseudo'")->getRow();

    if ($check_email->count > 0) {
        // L'email existe déjà, retourner false
        return 'Email déjà utilisé. Veuillez en choisir un autre.';
    }

    if ($check_pseudo->count > 0) {
        // Le pseudo existe déjà, retourner false
        return 'Ce pseudo est déjà pris. Veuillez en choisir un autre.';
    }

    // Si l'email et le pseudo sont uniques, procéder à l'insertion
    $sql = "INSERT INTO t_compte_cpt (cpt_pseudo, cpt_login, cpt_mot_passe, cpt_etat) VALUES ('".$pseudo."','".$mail."' , '".$mot."', 'A')";

    // Exécution de la requête
    if ($this->db->query($sql)) {
        // Si la requête réussit, retourner true ou un autre statut
        return true;
    } else {
        // Si la requête échoue, retourner false
        return 'Une erreur est survenue lors de l\'inscription. Veuillez réessayer.';
    }
}

public function get_pseudo($u)
    {
    
    $requete="SELECT `cpt_pseudo` FROM `t_compte_cpt`  WHERE `cpt_login`='".$u."';";
    $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }


    public function get_all_actualites($u)
    {
    $resultat = $this->db->query("SELECT * FROM `t_activite_att` JOIN t_compte_cpt WHERE  `cpt_login`='".$u."';");
    return $resultat->getResultArray();
    }


// Permet de récupérer le id 
 public function get_role($u)
 {
 $requete="SELECT `cpt_id` FROM `t_compte_cpt`  WHERE `cpt_login` ='".$u."';";
 $resultat = $this->db->query($requete);
 return $resultat->getRow();
 }

     


   
}

