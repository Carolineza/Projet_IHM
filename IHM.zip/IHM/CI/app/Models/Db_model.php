<?php
namespace App\Models;
use CodeIgniter\Model;


class Db_model extends Model
{
    protected $db;
    public function __construct()
    {
    $this->db = db_connect(); //charger la base de données
    // ou
    // $this->db = \Config\Database::connect();
    }
    

    public function connect_compte($u, $p)
{
    // Adaptation de la requête à la nouvelle structure de la table
    $sql = ("SELECT `cpt_login`, `cpt_mot_passe` FROM `t_compte_cpt` WHERE `cpt_etat` = 'A' AND `cpt_login` = '" . $u . "' AND `cpt_mot_passe` = '" . $p . "';");
    
    $resultat = $this->db->query($sql);
    
    if ($resultat->getNumRows() > 0) {
        return true;
    } else {
        return false;
    }
}


public function inscrire_utilisateur($u, $email, $p)
{
    // Utilisation d'une requête préparée pour éviter les injections SQL
    $mail = htmlspecialchars(addslashes($email));
    $pseudo = htmlspecialchars(addslashes($u));
    $mot = htmlspecialchars(addslashes($p));

    // Vérifier si l'email ou le pseudo existent déjà
    $check_email = $this->db->query("SELECT COUNT(*) as count FROM t_compte_cpt WHERE cpt_login = '$mail'")->getRow();
    $check_pseudo = $this->db->query("SELECT COUNT(*) as count FROM t_compte_cpt WHERE cpt_pseudo = '$pseudo'")->getRow();

    if ($check_email->count > 0) {
        // L'email existe déjà, retourner false
        return 'Email déjà utilisé. Veuillez en choisir un autre.';
    }

    if ($check_pseudo->count > 0) {
        // Le pseudo existe déjà, retourner false
        return 'Ce pseudo est déjà pris. Veuillez en choisir un autre.';
    }

    // Si l'email et le pseudo sont uniques, procéder à l'insertion
    $sql = "INSERT INTO t_compte_cpt (cpt_pseudo, cpt_login, cpt_mot_passe, cpt_etat) VALUES ('".$pseudo."','".$mail."' , '".$mot."', 'A')";

    // Exécution de la requête
    if ($this->db->query($sql)) {
        // Si la requête réussit, retourner true ou un autre statut
        return true;
    } else {
        // Si la requête échoue, retourner false
        return 'Une erreur est survenue lors de l\'inscription. Veuillez réessayer.';
    }
}

public function get_pseudo($u)
    {
    
    $requete="SELECT `cpt_pseudo` FROM `t_compte_cpt`  WHERE `cpt_login`='".$u."';";
    $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }




    public function get_all_actualites($u)
    {
    $resultat = $this->db->query("SELECT * FROM `t_activite_att` JOIN t_compte_cpt WHERE  `cpt_login`='".$u."';");
    return $resultat->getResultArray();
    }


// Permet de récupérer le id 
 public function get_role($u)
 {
 $requete="SELECT `cpt_id` FROM `t_compte_cpt`  WHERE `cpt_login` ='".$u."';";
 $resultat = $this->db->query($requete);
    $row = $resultat->getRow();
    
    // Vérifier si une ligne a été retournée
    if ($row) {
        // Récupérer la valeur de la colonne cpt_id et la convertir en entier
        $cpt_id = (int) $row->cpt_id;
        return $cpt_id;
    } else {
        // Gérer le cas où aucun résultat n'est retourné
        return null; // Ou toute autre valeur par défaut que vous souhaitez retourner
    }
 }

 public function save_activity($id, $saisie) {
    // Préparation de la requête SQL avec des paramètres pour éviter les injections SQL
       $nom = htmlspecialchars(addslashes($saisie['activity-name']));
       $visibilite =htmlspecialchars(addslashes($saisie['activity-day']));
       $duree = htmlspecialchars(addslashes($saisie['duration']));
       $distance =  htmlspecialchars(addslashes($saisie['distance']));
       $calorie =  htmlspecialchars(addslashes($saisie['calories']));
       $date =  htmlspecialchars(addslashes($saisie['start-time']));

     
     $sql="INSERT INTO `t_activite_att` VALUES (NULL, '.$id.', '".$nom."', '".$date."', '.$calorie.', '".$visibilite."', '".$duree."', '.$distance.');";
    // Préparer la requête
    return $this->db->query($sql);

    // Exécution de la requête
    
}

public function get_abomment($u)
{
$requete="SELECT COUNT(`abb_cible_id`) AS nb FROM `t_abonnement_abb` WHERE `abb_cible_id`=".$u.";";
$resultat = $this->db->query($requete);
return $resultat->getRow();
   
   // Vérifier si une ligne a été retournée
  
}

public function get_abonne($u)
{
$requete="SELECT COUNT(`abb_abonne_id`) AS nb FROM `t_abonnement_abb` WHERE `abb_abonne_id`=".$u.";";
$resultat = $this->db->query($requete);
 return $resultat->getRow();

}

public function get_inviteur($u)
{
$requete="SELECT `t_compte_cpt`.`cpt_pseudo` 
FROM `t_compte_cpt` 
JOIN `t_invitation_inv` 
ON `t_compte_cpt`.`cpt_id` = `t_invitation_inv`.`inviteur_id`
WHERE `t_invitation_inv`.`invite_id`=".$u.";";

$resultat = $this->db->query($requete);
return $resultat->getResultArray();

}

public function get_envoi_invite($u, $id)
{
    // Préparer et exécuter la requête pour vérifier si le pseudo existe
    $requete = "SELECT COUNT(*) > 0 AS pseudo_existe FROM t_compte_cpt WHERE cpt_pseudo = ?";
    $resultat = $this->db->prepare($requete);
    $resultat->execute([$u]);
    $row = $resultat->fetch();

    if ($row['pseudo_existe']) {
        // Si le pseudo existe, insérer l'invitation
        $requete2 = "INSERT INTO t_invitation_inv (inviteur_id, invite_id)
                     SELECT inviter.cpt_id, invite.cpt_id
                     FROM t_compte_cpt AS inviter
                     JOIN t_compte_cpt AS invite ON invite.cpt_pseudo = ?
                     WHERE inviter.cpt_pseudo = ?";
        $resultat2 = $this->db->prepare($requete2);
        return $resultat2->execute([$u, $id]);
    } else {
        return false;
    }
}




   
}

