<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - Sport Zone</title>
    <link rel="stylesheet" href="<?= base_url('public/CSS/connexion-style.css'); ?>">
</head>
<body>
    <!-- Barre supérieure -->
    <header class="header">
        <h1>Sport Zone</h1>
        <nav class="nav-bar">
            <a href="index.html">Accueil</a>
            <a href="profile.html">Mon Profil</a>
            <a href="<?= base_url('activite/deconnecter'); ?>" class="nav-link login-link">Déconnexion</a>
        </nav>
    </header>

    <!-- Contenu principal -->
    <?php
    $session=session();
?>
    <main class="main-content">
        <!-- Colonne de gauche : Sélection du sport -->
        <aside class="sidebar">
            <div class="user-card">
                <div class="profile-initial">C</div>
                <p class="user-name"><?php echo $pseudo->cpt_pseudo;  echo '<br>';  echo $session->get('user'); ?></p>
                <p class="user-info">Abonnements : 0 | Abonnés : 0</p>
            </div>

            <div class="sport-selection">
                <h3>Choisissez votre sport</h3>
                <ul class="sport-icons">
                    <li>
                        <button class="sport-btn" data-sport="Course à pied">
                            <img src="<?= base_url('public/images/course_icone.webp'); ?>" alt="Icône course à pied">
                        </button>
                    </li>
                    <li>
                        <button class="sport-btn" data-sport="Cyclisme">
                            <img src="<?= base_url('public/images/cyclisme_Icone.webp'); ?>" alt="Icône cyclisme">
                        </button>
                    </li>
                    <li>
                        <button class="sport-btn" data-sport="Natation">
                            <img src="<?= base_url('public/images/swimming.webp'); ?>" alt="Icône natation">
                        </button>
                    </li>
                    <li>
                        <button class="sport-btn" data-sport="Marche">
                            <img src="<?= base_url('public/images/marche_icone.webp'); ?>" alt="Icône marche">
                        </button>
                    </li>
                </ul>
            </div>

            <div class="days-tracker">
                <h4>Cette semaine</h4>
                <div class="days">
                    <span>L</span>
                    <span>M</span>
                    <span>M</span>
                    <span>J</span>
                    <span>V</span>
                    <span>S</span>
                    <span>D</span>
                </div>
            </div>

            <!-- Section pour découvrir vos amis -->
            <div class="friends-section">
                <h3>Découvrez ce que font vos amis</h3>
                <p>Recherchez des amis et partagez vos performances ensemble. Invitez-les à rejoindre votre aventure sportive.</p>
                <div class="search-bar">
                    <input type="text" id="search-friends" placeholder="Nom de l'ami ou de l'athlète">
                    <button onclick="searchFriends()">Rechercher</button>
                </div>
            </div>
        </aside>

        <!-- Section principale -->
        <section class="dashboard" id="dashboard-content">
            <!-- Bannière de bienvenue -->
            <div class="welcome-banner">
                <h2>Bienvenue sur Sport Zone</h2>
                <p>Enregistrez votre première activité pour commencer à suivre vos performances.</p>
                <p id="selected-sport">Sport sélectionné : Aucun</p>
            </div>

            <!-- Section actions -->
            <div class="actions-section">
                <div class="action-card">
                    <img src="<?= base_url('public/images/reg.webp'); ?>" alt="Icône d'enregistrement d'une activité" class="action-icon">
                    <div class="action-content">
                        <h3>Enregistrez une activité</h3>
                        <p>Ajoutez une activité pour suivre vos progrès et fixer des objectifs adaptés à vos besoins.</p>
                        <button onclick="redirectToForm()" class="primary-btn">Enregistrer une activité</button>
                    </div>
                </div>

                <div class="action-card">
                    <img src="<?= base_url('public/images/statistics.webp'); ?>" alt="Icône des statistiques" class="action-icon">
                    <div class="action-content">
                        <h3>Découvrez vos statistiques</h3>
                        <p>Visualisez vos performances après avoir ajouté une activité.</p>
                        <button class="primary-btn">Voir les statistiques</button>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Pied de page -->
    <footer class="footer">
        <p>&copy; 2024 Sport Zone. Tous droits réservés.</p>
    </footer>

    <script src="JS/connexion.js"></script>
</body>
</html>
