<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Activités - Sport Zone</title>
    <link rel="stylesheet" href="<?= base_url('public/CSS/activities-style.css'); ?>">
</head>
<body>
    <header class="header">
        <h1>Sport Zone</h1>
        <nav class="nav-bar">
            <a  href="<?= base_url('afficher/retour'); ?>">Retour</a>
        </nav>
    </header>
<?php

if (! empty($new) && is_array($new))
{

    echo ' <main class="activities-container">
                    <!-- Bannière avec icône et texte -->
                    <section class="banner">
                        <div class="banner-text">
                            <h2>Mes Activités</h2>
                            <p>Visualisez et gérez toutes vos activités sportives enregistrées ici.</p>
                            
                        </div>
                    </section>';
          echo ' <!-- Tableau des activités -->
                    <section class="activities-list">
                        <h3>Historique des activités</h3>
                        <table class="activities-table">
                            <thead>
                                <tr>
                                    <th>Sport</th>
                                    <th>Jour</th>
                                    <th>Durée</th>
                                </tr>
                            </thead>
                       <tbody id="activities-tbody">';
                    

                       foreach ($new as $actu) {
                        echo '<tr>';
                        echo '<td>' . htmlspecialchars($actu['att_nom']) . '</td>';
                        echo '<td>' . htmlspecialchars($actu['att_date']) . '</td>';
                        echo '<td>' . htmlspecialchars($actu['att_duree']) . '</td>';
                        echo '</tr>';
                    }
            echo '</tbody>
                    </table>
                      </section>
                         </main>';
    
}            
?>




    <footer class="footer">
        <p>&copy; 2024 Sport Zone. Tous droits réservés.</p>
    </footer>

</body>
</html>
