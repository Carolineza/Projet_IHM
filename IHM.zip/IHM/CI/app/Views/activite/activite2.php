<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=n, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<button ><a href="<?= base_url('activite/deconnecter'); ?>" class="nav-link login-link">deconnecter</a></button>
    <li> CE-CI EST LA PAGE ACTIVITE </li>
    <?php
    $session=session();
    echo $session->get('user');
    echo '<br>';
    echo $pseudo->cpt_pseudo; 
    
    if (! empty($new) && is_array($new))
{

                          echo'  <div class="row">
                        <div class="">
                            <div class="card flex-fill">
                                <div class="card-header">

                                    <h5 class="card-title mb-0"> ATELIER </h5>
                                </div>';

                            echo '<table class="table table-hover my-0">
                                    <thead>
                                        <tr>
                                            <th>Nom</th>
                                            <th class="d-none d-xl-table-cell">Date de l\' atelier</th>
                                            <th>present</th>
                                            <th class="d-none d-md-table-cell"> Description </th>
                                        </tr>
                                    </thead>
                                    <tbody>';

                            foreach ($new as $ate) {
                            echo '</tr>';
                            echo '<td>'.$ate['att_nom'].'</td>';
                            echo '<td>'.$ate['att_date'].'</td>';
                            echo '<td>'.$ate['att_calories'].'</td>';
                            echo '<td>'.$ate['att_visibilite'].'</td>';
                            echo '</tr>';

    }
    echo '</tbody>
                                </table>
                            </div>
                        </div>';
} 
?>


</body>
</html>