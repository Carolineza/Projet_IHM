<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajouter une activité - Sport Zone</title>
    <link rel="stylesheet" href="<?= base_url('public/CSS/activite-style.css'); ?>">
</head>
<body>
    <header class="header">
        <h1>Ajouter une activité</h1>
        <nav class="nav-bar">
            <a href="<?= base_url('afficher/retour'); ?>">Retour</a>
        </nav>
    </header>

    <main class="activity-form">
        <section class="activity-details">

            <!-- Display success or error message -->
            <?php if (session()->getFlashdata('success_message')): ?>
                <div class="message success">
                    <?= session()->getFlashdata('success_message'); ?>
                </div>
            <?php endif; ?>

            <?php if (session()->getFlashdata('error_message')): ?>
                <div class="message error">
                    <?= session()->getFlashdata('error_message'); ?>
                </div>
            <?php endif; ?>
         <form action="<?= base_url('activite/ajoute'); ?>" method="POST" class="form">
            <div class="activity-header">
            <img id="activity-icon" src="images/default-icon.webp" alt="Icone activité">
                <h2 id="activity-name">Sport : Non défini</h2>
                <!-- Champ caché pour envoyer le nom de l'activité -->
                <input type="hidden" id="hidden-activity-name" name="activity-name" value="Nd">

            </div>

            
        
                <div class="form-group">
                    <label for="activity-day">Visibilité :</label>
                    <select id="activity-day" name="activity-day" class="modern-dropdown" required>
                        <option value="" disabled selected>Choisissez un jour</option>
                        <option value="V">Public</option>
                        <option value="N">Privé</option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="duration">Durée :</label>
                    <input type="time" id="duration" name="duration" required>
                </div>

                <div class="form-group">
                    <label for="distance">Distance (en km) :</label>
                    <input type="number" id="distance" name="distance" step="0.01" placeholder="0.00" min="0" required>
                </div>

                <div class="form-group">
                    <label for="calories">Calories (en kcal) :</label>
                    <input type="number" id="calories" name="calories" placeholder="0" min="0" required>
                </div>

                <div class="form-group">
                    <label for="start-time">Heure de début :</label>
                    <input type="datetime-local" id="start-time" name="start-time" required>
                </div>
               
                <button type="submit" class="primary-btn">Ajouter l'activité</button>
            </form>
        </section>
    </main>

    <footer class="footer">
        <p>&copy; 2024 Sport Zone. Tous droits réservés.</p>
    </footer>

    <script src="<?= base_url('public/JS/activite.js'); ?>"></script>
</body>
</html>
