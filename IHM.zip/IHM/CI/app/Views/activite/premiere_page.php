<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord - Sport Zone</title>
    <link rel="stylesheet" href="<?= base_url('public/CSS/connexion-style.css'); ?>">
</head>
<body>
    <!-- Barre supérieure -->
    <header class="header">
        <h1>Sport Zone</h1>
        <nav class="nav-bar">
            <a href="<?= base_url('/'); ?>">Accueil</a>
            <a href="profile.html">Mon Profil</a>
            <a href="<?= base_url('activite/deconnecter'); ?>" class="nav-link login-link">Déconnexion</a>
        </nav>
    </header>

    <!-- Contenu principal -->
    <main class="main-content">
        <!-- Colonne de gauche : Invités -->
        <aside class="sidebar">
            <div class="user-card">
                <div class="profile-initial">C</div>
                <p class="user-name">Carole Ineza</p>
                <p class="user-info">Abonnements : <?php echo $cible->nb ?> | Abonnés : <?php echo $abonne->nb ?></p>
            </div>

            <div class="invites-section">
                <h3>Invités</h3>
                <ul id="invites">
                <?php foreach ($invites as $invite): ?>
                    <li>
                        <?= htmlspecialchars($invite['cpt_pseudo']); ?>
                        <button >Accepter</button>
                        <button >Refuser</button>
                    </li>
                <?php endforeach; ?>
            </ul>

            </div>
            
            <!-- Section de recherche d'amis -->
            <div class="friends-section">
                <h3>Découvrez ce que font vos amis</h3>
                <p>Recherchez des amis et partagez vos performances ensemble. Invitez-les à rejoindre votre aventure sportive.</p>
                <form action="<?= base_url('afficher/ajoute_invite'); ?>" method="POST" class="form">
                    <!-- Affichage des messages flash -->
                        <?php if (session()->getFlashdata('success_message')) : ?>
                            <div class="alert alert-success">
                                <?= session()->getFlashdata('success_message'); ?>
                            </div>
                        <?php endif; ?>

                        <?php if (session()->getFlashdata('error_message')) : ?>
                            <div class="alert alert-danger">
                                <?= session()->getFlashdata('error_message'); ?>
                            </div>
                        <?php endif; ?>

                        <!-- Formulaire -->
                        <div class="search-bar">
                            <input type="text" id="search-friends" name="search-friends" placeholder="Pseudo de l'ami ou email" required>
                            <button type="submit">Invite</button>
                        </div>

                </form>
            </div>
        </aside>

        <!-- Section principale -->
        <section class="dashboard">
            <!-- Bannière de bienvenue -->
            <div class="welcome-banner">
                <h2>Bienvenue sur Sport Zone</h2>
                <p>Enregistrez votre première activité pour commencer à suivre vos performances.</p>
            
            </div>

            <!-- Sélection des sports -->
            <div class="sport-selection">
            <div class="action-content">
            <hr>
            <h2>Enregistrez une activité</h2>
            <hr>
                <p>Ajoutez une activité pour suivre vos progrès et fixer des objectifs adaptés à vos besoins.</p>
            </div>

                <h3>Choisissez votre sport</h3>
                <ul class="sport-icons">
                    <li><button class="sport-btn" data-sport="Course à pied"><img src="<?= base_url('public/images/course_icone.webp')?> " alt="Course à pied"><p>Course à pied</p></button></li>
                    <li><button class="sport-btn" data-sport="Cyclisme"><img src="<?= base_url('public/images/cyclisme_Icone.webp')?> " alt="Cyclisme"><p>Cyclisme</p></button></li>
                    <li><button class="sport-btn" data-sport="Natation"><img src="<?= base_url('public/images/swimming.webp')?> " alt="Natation"><p>Natation</p></button></li>
                    <li><button class="sport-btn" data-sport="Marche"><img src="<?= base_url('public/images/marche_icone.webp')?> " alt="Marche"><p>Marche</p></button></li>
                </ul>
            </div>

           

            <!-- Section actions -->
            <div class="actions-section">
                <div class="action-card">
                    <img src="<?= base_url('public/images/reg.webp')?> " alt="Enregistrer une activité" class="action-icon">
                    <div class="action-content">
                        <!-- Bouton pour visualiser les activités, avec une explication plus claire -->
                        <a href="<?= base_url('afficher/activite'); ?>" class="primary-btn">Voir les activités disponibles</a>
                        <p>Cliquez sur le bouton ci-dessus pour consulter la liste des activités disponibles et obtenir plus de détails.</p>
                    </div>


                </div>

                <div class="action-card">
                    <img src="<?= base_url('public/images/statistics.webp')?> " alt="Statistiques" class="action-icon">
                    <div class="action-content">
                        <h3>Découvrez vos statistiques</h3>
                        <p>Visualisez vos performances après avoir ajouté une activité.</p>
                        <a href="<?= base_url('afficher/state'); ?>" class="primary-btn">Voir les statistiques</a>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Pied de page -->
    <footer class="footer">
        <p>&copy; 2024 Sport Zone. Tous droits réservés.</p>
    </footer>

    <script src="<?= base_url('public/JS/connexion.js'); ?>"></script>
</body>
</html>
