<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Sport Zone</title>
    <link rel="stylesheet" href="<?= base_url('public/CSS/compte-style.css'); ?>">
</head>

<body>
    <!-- En-tête de la page -->
    <header class="header">
        <h1><a href="<?= base_url('/'); ?>" class="logo">Sport Zone</a></h1>
    </header>

    <!-- Contenu principal avec le formulaire de connexion -->
    <main class="main-content">
        <div class="login-container">
            <h2>Connexion</h2>
            <form  action="<?= base_url('afficher/connexion'); ?>" method="POST" class="form">
                <div class="form-group">
                    <label for="email">Email :</label>
                    <input type="email" id="email" name="email" placeholder="Entrez votre email" required>
                </div>

                <div class="form-group">
                    <label for="password">Mot de passe :</label>
                    <input type="password" id="password" name="password" placeholder="Entrez votre mot de passe" required>
                </div>
                <!-- Error message for incorrect email or password -->
                    <?php if (isset($alert)): ?>
                        <div class="alert alert-danger" style="text-align: center;">
                            <?= $alert; ?>
                        </div>
                    <?php endif; ?>

                    <?php if (!empty($erreur) && is_array($erreur)): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php foreach ($erreur as $dif): ?>
                                    <li><?= $dif ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                <button type="submit"  class="submit-button">Se connecter </button>         
            </form>
            
            <p>Vous n'avez pas de compte ?<a href="<?= base_url('afficher/creation'); ?>"> Créer un compte</a></p>
        </div>
    </main>

    <!-- Pied de page -->
    <footer class="footer">
        <p>&copy; 2024 Sport Zone. Tous droits réservés.</p>
    </footer>
</body>
</html>