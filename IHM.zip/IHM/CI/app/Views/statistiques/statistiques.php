<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistiques - Sport Zone</title>
    <link rel="stylesheet" href="<?= base_url('public/CSS/statistics-style.css'); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header class="header">
        <h1>Statistiques</h1>
        <nav class="nav-bar">
            <a href="<?= base_url('afficher/retour'); ?>" class="nav-link"><i class="fas fa-arrow-left"></i> Retour</a>
        </nav>
    </header>


    <main class="stats-overview">
        <section class="date-summary">
        <h2 id="selected-date">Aujourd'hui : 03 déc. 2024</h2>
            <p class="subtitle">Sélectionnez un jour pour afficher vos performances.</p>
            <div class="days-container">
                <span class="day-circle active" data-day="Lundi">L</span>
                <span class="day-circle" data-day="Mardi">M</span>
                <span class="day-circle" data-day="Mercredi">M</span>
                <span class="day-circle" data-day="Jeudi">J</span>
                <span class="day-circle" data-day="Vendredi">V</span>
                <span class="day-circle" data-day="Samedi">S</span>
                <span class="day-circle" data-day="Dimanche">D</span>
            </div>
        </section>

        <section class="quick-summary">
            <h3>Statistiques globale</h3>
            <div class="quick-stats">
                <div class="stat-card">
                    <i class="fas fa-running"></i>
                    <p>Activités : <span>5</span></p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-fire"></i>
                    <p>Calories brûlées : <span>1200 kcal</span></p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-walking"></i>
                    <p>Distance totale : <span>22 km</span></p>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <p>&copy; 2024 Sport Zone. Tous droits réservés.</p>
    </footer>

    <script src="<?= base_url('JS/statistics.js'); ?>"></script>
    

</body>
</html>
