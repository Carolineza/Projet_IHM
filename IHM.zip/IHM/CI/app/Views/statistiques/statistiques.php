<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Statistiques - Sport Zone</title>
    <link rel="stylesheet" href="<?= base_url('public/CSS/statistics-style.css'); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <header class="header">
        <h1>Statistiques</h1>
        <nav class="nav-bar">
            <a href="<?= base_url('afficher/retour'); ?>" class="nav-link"><i class="fas fa-arrow-left"></i> Retour</a>
        </nav>
    </header>


    <main class="stats-overview">
        <section class="date-summary">
        <h2 id="selected-date"></h2>
            <script>
            // Fonction pour mettre à jour la date automatiquement
            function updateDate() {
                const dateElement = document.getElementById('selected-date');
                const today = new Date();
                const options = { day: '2-digit', month: 'short', year: 'numeric' };
                const formattedDate = `Aujourd'hui : ${today.toLocaleDateString('fr-FR', options)}`;
                
                dateElement.textContent = formattedDate;
            }

            // Appel de la fonction pour afficher la date
            updateDate();
            </script>
            
        </section>

         <!-- Grand cercle pour les calories -->
         <section class="circle-stats">
            <div class="container">
        <h1>Graphique de la semaine</h1>
        <canvas id="myChart"></canvas>
    </div>

    <script>
        // Récupérer le contexte du canvas
        var ctx = document.getElementById('myChart').getContext('2d');

        // Créer un graphique en utilisant Chart.js
        var myChart = new Chart(ctx, {
            type: 'bar', // Type de graphique (barres)
            data: {
                labels: ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi','Samedi', 'Dimanche'], // Mois
                datasets: [{
                    label: 'calories', // Nom de la série
                    data: [<?php echo (int) $lundi->calorie; ?>, <?php echo (int) $mardi->calorie; ?>, <?php echo (int) $mercredi->calorie; ?>,
                    <?php echo (int) $jeudi->calorie; ?>,<?php echo (int) $vendredi->calorie; ?>,<?php echo (int) $samedi->calorie; ?>,
                    <?php echo (int) $dimanche->calorie; ?> ], // Données des ventes
                    backgroundColor: 'rgba(54, 162, 235, 0.2)', // Couleur des barres
                    borderColor: 'rgba(54, 162, 235, 1)', // Couleur des bordures
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true, // Le graphique est réactif
                scales: {
                    y: {
                        beginAtZero: true // Commencer l'axe Y à zéro
                    }
                }
            }
        });
    </script>
        </section>

        <section class="quick-summary">
            <h3>Statistiques globale</h3>
            <div class="quick-stats">
                <div class="stat-card">
                    <i class="fas fa-running"></i>
                    <p>Activités : <span><?php echo $semaine->nb ?></span></p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-fire"></i>
                    <p>Calories brûlées : <span><?php echo $semaine->calorie ?> kcal</span></p>
                </div>
                <div class="stat-card">
                    <i class="fas fa-walking"></i>
                    <p>Distance totale : <span><?php echo $semaine->distance ?>km</span></p>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <p>&copy; 2024 Sport Zone. Tous droits réservés.</p>
    </footer>

    <script src="<?= base_url('JS/statistics.js'); ?>"></script>
    

</body>
</html>
