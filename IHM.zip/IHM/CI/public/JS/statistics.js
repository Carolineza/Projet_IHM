document.addEventListener("DOMContentLoaded", () => {

    const days = document.querySelectorAll(".day-circle");

    days.forEach((day) => {
        day.addEventListener("click", () => {
            // Retirer la classe active des autres jours
            days.forEach((d) => d.classList.remove("active"));

            // Ajouter la classe active au jour sélectionné
            day.classList.add("active");

            // Mettre à jour la date sélectionnée
            const selectedDate = document.getElementById("selected-date");
            selectedDate.textContent = `Statistiques pour : ${day.getAttribute("data-day")}`;
        });
    });
    
    document.addEventListener('DOMContentLoaded', function() {
        // Sélectionner l'élément contenant la date
        let dateElement = document.getElementById('selected-date');
        
        if (dateElement) {
            // Obtenir la date actuelle
            let today = new Date();
            
            // Options de formatage
            let options = { day: '2-digit', month: 'short', year: 'numeric' };
            
            // Formatter la date (par exemple, "02 déc. 2024")
            let formattedDate = today.toLocaleDateString('fr-FR', options);
            
            // Mettre à jour le contenu de l'élément
            dateElement.textContent = `Aujourd'hui : ${formattedDate}`;
        } else {
            console.warn('Élément #selected-date introuvable');
        }
    });

    const ctx = document.getElementById('calories-chart').getContext('2d');
    const data = {
        labels: ['00:00', '06:00', '12:00', '18:00', '00:00'],
        datasets: [{
            label: 'Calories brûlées',
            data: [50, 100, 200, 150, 250],
            borderColor: '#ff4081',
            backgroundColor: 'rgba(255, 64, 129, 0.2)',
            borderWidth: 2,
            fill: true,
            tension: 0.4
        }]
    };

    new Chart(ctx, {
        type: 'line',
        data: data,
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                }
            },
            scales: {
                x: {
                    beginAtZero: true
                },
                y: {
                    beginAtZero: true
                }
            }
        }
    });

});







