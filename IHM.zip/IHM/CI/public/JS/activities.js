document.addEventListener("DOMContentLoaded", () => {
    const activitiesTbody = document.getElementById("activities-tbody");

    // Charger les activités depuis localStorage
    const activities = JSON.parse(localStorage.getItem("activities")) || [];

    if (activities.length > 0) {
        activities.forEach(activity => {
            const row = document.createElement("tr");

            row.innerHTML = `
                <td><img src="${activity.icon}" alt="${activity.sport}" class="activity-icon"> ${activity.sport}</td>
                <td>${activity.day}</td>
                <td>${activity.duration}</td>
                <td>${activity.distance}</td>
                <td>${activity.calories}</td>
                <td>${activity.startTime}</td>
            `;

            activitiesTbody.appendChild(row);
        });
    } else {
        const noDataRow = document.createElement("tr");
        noDataRow.innerHTML = `<td colspan="6" style="text-align:center;">Aucune activité ajoutée pour l'instant.</td>`;
        activitiesTbody.appendChild(noDataRow);
    }
});
