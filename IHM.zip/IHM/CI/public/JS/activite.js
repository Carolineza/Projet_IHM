document.addEventListener("DOMContentLoaded", () => {
        // Récupération du sport sélectionné depuis le stockage local
        const selectedSport = JSON.parse(localStorage.getItem("selectedSport"));
    
        if (selectedSport && selectedSport.icon && selectedSport.name) {
            // Mettre à jour l'icône et le nom de l'activité
            const activityIcon = document.getElementById("activity-icon");
            const activityName = document.getElementById("activity-name");
            const hiddenActivityInput = document.getElementById('hidden-activity-name');
    
            // Vérifie que les éléments existent dans le DOM avant de les utiliser
            if (activityIcon && activityName && hiddenActivityInput) {
                // Mettre à jour les éléments avec les informations du sport
                activityIcon.src = selectedSport.icon;
                activityName.textContent = `Sport : ${selectedSport.name}`;
    
                // Mettre à jour l'input caché avec le nom du sport
                hiddenActivityInput.value = `${selectedSport.name}`; // Sans "Sport :" pour garder la valeur propre
            } else {
                console.error("Certains éléments du DOM sont manquants !");
            }
        } else {
            alert("Aucun sport sélectionné. Veuillez revenir au tableau de bord et sélectionner un sport.");
        }
  
    

    // Gestion de la soumission du formulaire d'activité
    const activityForm = document.getElementById("activity-entry-form");
    activityForm.addEventListener("submit", (event) => {
        event.preventDefault();

        // Récupérer les valeurs saisies dans le formulaire
        const activityDay = document.getElementById("activity-day").value;
        const duration = document.getElementById("duration").value;
        const distance = document.getElementById("distance").value;
        const calories = document.getElementById("calories").value;
        const startTime = document.getElementById("start-time").value;

        // Vérifier que tous les champs sont remplis
        if (!activityDay) {
            alert("Veuillez choisir un jour pour l'activité.");
            return;
        }

        // Afficher un message de confirmation ou envoyer les données au serveur
        alert(
            `Activité ajoutée avec succès :
            Sport : ${selectedSport.name}
            Jour : ${activityDay}
            Durée : ${duration}
            Distance : ${distance} km
            Calories : ${calories} kcal
            Début : ${startTime}`
        );

        // TODO : Envoyer les données au serveur via une requête POST si nécessaire
        // Exemple avec fetch API :
        // fetch('/api/ajouter-activite', {
        //     method: 'POST',
        //     headers: {
        //         'Content-Type': 'application/json'
        //     },
        //     body: JSON.stringify({
        //         sport: selectedSport.name,
        //         icon: selectedSport.icon,
        //         day: activityDay,
        //         duration: duration,
        //         distance: distance,
        //         calories: calories,
        //         startTime: startTime
        //     })
        // }).then(response => response.json()).then(data => {
        //     console.log(data);
        //     alert("Activité enregistrée !");
        // }).catch(error => {
        //     console.error("Erreur lors de l'enregistrement de l'activité :", error);
        // });
    });
});
