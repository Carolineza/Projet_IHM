// Gestion du changement de sport sélectionné
const sportButtons = document.querySelectorAll(".sport-btn");
const selectedSportDisplay = document.getElementById("selected-sport");

// Met à jour l'affichage en fonction du sport sélectionné
sportButtons.forEach((button) => {
    button.addEventListener("click", () => {
        const sportName = button.getAttribute("data-sport");
        selectedSportDisplay.textContent = `Sport sélectionné : ${sportName}`;
        showActionsSection(sportName); // Afficher la section d'actions pour ce sport
    });
});

// Affiche la section d'actions avec le sport sélectionné
function showActionsSection(sportName) {
    const welcomeBanner = document.querySelector(".welcome-banner");
    const actionsSection = document.querySelector(".actions-section");
    welcomeBanner.style.display = "block";
    actionsSection.style.display = "block";
    const sportIndicator = document.getElementById("selected-sport");
    sportIndicator.textContent = `Sport sélectionné : ${sportName}`;
}

// Redirection vers le formulaire d'enregistrement d'activité
function redirectToForm() {
    window.location.href = "enregistrement_activite.html";
}

// Gestion de la recherche d'amis
function searchFriends() {
    const searchInput = document.getElementById("search-friends").value.trim();
    if (searchInput) {
        alert(`Vous avez recherché : ${searchInput}`);
        // Ajoutez ici une logique pour rechercher dans une base de données ou une API
    } else {
        alert("Veuillez entrer un nom à rechercher !");
    }
}

// Gestion de la sélection des jours
const dayButtons = document.querySelectorAll(".days span");

// Ajoute un style actif au jour sélectionné
dayButtons.forEach((day) => {
    day.addEventListener("click", () => {
        // Retire la classe active de tous les jours
        dayButtons.forEach((btn) => btn.classList.remove("active-day"));
        // Ajoute la classe active au jour cliqué
        day.classList.add("active-day");
        alert(`Jour sélectionné : ${day.textContent}`);
    });
});

// Ajout de styles pour le jour sélectionné
function setDayStyle(day) {
    const days = document.querySelectorAll(".days span");
    days.forEach((d) => d.classList.remove("selected"));
    day.classList.add("selected");
}
