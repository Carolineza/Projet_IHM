// Sélectionnez tous les boutons avec la classe sport-btn
const sportButtons = document.querySelectorAll(".sport-btn");

// Vérifiez que baseUrl est défini
if (typeof baseUrl !== 'undefined' && baseUrl) {
    // Ajoutez des écouteurs d'événements à chaque bouton
    sportButtons.forEach((button) => {
        button.addEventListener("click", () => {
            const sportName = button.getAttribute("data-sport");
            const sportIcon = button.querySelector("img").src;

            // Enregistrez le sport sélectionné dans localStorage
            localStorage.setItem("selectedSport", JSON.stringify({ name: sportName, icon: sportIcon }));

            // Redirigez vers une nouvelle page
            window.location.href = `${baseUrl}activite/ajoute`;
        });
    });
} else {
    console.error("baseUrl n'est pas défini");
}

