document.addEventListener("DOMContentLoaded", () => {
    const sportsList = document.querySelector(".sports-list");
    const sportsItems = document.querySelectorAll(".sport-item");
    const prevBtn = document.getElementById("prev-btn");
    const nextBtn = document.getElementById("next-btn");

    let currentIndex = 0;
    const totalSlides = sportsItems.length;

    const updateCarousel = () => {
        const offset = -currentIndex * 100; // Décale les slides horizontalement
        sportsList.style.transform = `translateX(${offset}%)`;
    };

    nextBtn.addEventListener("click", () => {
        currentIndex = (currentIndex + 1) % totalSlides; // Passe au suivant
        updateCarousel();
    });

    prevBtn.addEventListener("click", () => {
        currentIndex = (currentIndex - 1 + totalSlides) % totalSlides; // Revient au précédent
        updateCarousel();
    });

    // Défilement automatique toutes les 5 secondes
    setInterval(() => {
        currentIndex = (currentIndex + 1) % totalSlides;
        updateCarousel();
    }, 5000);
});
