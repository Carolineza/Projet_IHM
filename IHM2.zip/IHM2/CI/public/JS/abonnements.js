document.addEventListener("DOMContentLoaded", () => {
    // Fonction pour gérer le désabonnement
    window.unsubscribe = (userName) => {
        const confirmUnsub = confirm(`Voulez-vous vraiment vous désabonner de ${userName} ?`);
        if (confirmUnsub) {
            alert(`Vous êtes maintenant désabonné de ${userName}.`);
            // Logique pour supprimer l'abonnement côté serveur ou dans les données locales
        }
    };
});

