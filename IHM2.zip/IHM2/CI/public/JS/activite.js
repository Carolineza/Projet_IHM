document.addEventListener("DOMContentLoaded", () => {
        // Récupération du sport sélectionné depuis le stockage local
        const selectedSport = JSON.parse(localStorage.getItem("selectedSport"));
    
        if (selectedSport && selectedSport.icon && selectedSport.name) {
            // Mettre à jour l'icône et le nom de l'activité
            const activityIcon = document.getElementById("activity-icon");
            const activityName = document.getElementById("activity-name");
            const hiddenActivityInput = document.getElementById('hidden-activity-name');
    
            // Vérifie que les éléments existent dans le DOM avant de les utiliser
            if (activityIcon && activityName && hiddenActivityInput) {
                // Mettre à jour les éléments avec les informations du sport
                activityIcon.src = selectedSport.icon;
                activityName.textContent = `Sport : ${selectedSport.name}`;
    
                // Mettre à jour l'input caché avec le nom du sport
                hiddenActivityInput.value = `${selectedSport.name}`; // Sans "Sport :" pour garder la valeur propre
            } else {
                console.error("Certains éléments du DOM sont manquants !");
            }
        } else {
            alert("Aucun sport sélectionné. Veuillez revenir au tableau de bord et sélectionner un sport.");
        }
  
    

    
    
});
