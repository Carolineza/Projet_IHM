<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Sport Zone</title>
    <link rel="stylesheet" href="<?= base_url('public/CSS/compte-style.css'); ?>">
    <style>
        /* Style de la popup */
        .popup {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0);
            background-color: #fff;
            color: #333;
            border: 1px solid #ddd;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.3);
            padding: 25px;
            z-index: 1000;
            text-align: center;
            width: 90%;
            max-width: 400px;
            opacity: 0;
            transition: transform 0.3s ease, opacity 0.3s ease;
        }

        .popup.show {
            transform: translate(-50%, -50%) scale(1);
            opacity: 1;
        }

        .popup-header {
            font-size: 18px;
            font-weight: bold;
            color: #dc3545;
            margin-bottom: 10px;
        }

        .popup-message {
            font-size: 16px;
            color: #555;
            margin-bottom: 20px;
        }

        .popup .close-btn {
            display: inline-block;
            margin-top: 10px;
            padding: 12px 20px;
            background: #dc3545;
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            font-size: 14px;
            transition: background 0.3s ease;
        }

        .popup .close-btn:hover {
            background: #c82333;
        }

        /* Animation pour le fond sombre */
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
            display: none;
            opacity: 0;
            transition: opacity 0.3s ease;
        }

        .overlay.show {
            display: block;
            opacity: 1;
        }

    </style>
</head>
<body>
    <!-- En-tête de la page -->
    <header class="header">
        <h1><a href="<?= base_url('/'); ?>" class="logo">Sport Zone</a></h1>
        <a href="<?= base_url('/'); ?>" class="login-link"> ACCUEIL</a>
    </header>

    <!-- Contenu principal avec le formulaire de connexion -->
    <main class="main-content">
        <div class="login-container">
            <h2>Connexion</h2>
            <form action="<?= base_url('afficher/connexion'); ?>" method="POST" class="form">
                <div class="form-group">
                    <label for="email">Email :</label>
                    <input type="email" id="email" name="email" placeholder="Entrez votre email" required>
                </div>

                <div class="form-group">
                    <label for="password">Mot de passe :</label>
                    <input type="password" id="password" name="password" placeholder="Entrez votre mot de passe" required>
                </div>

                <!-- Gestion des erreurs -->
                <?php if (isset($alert)): ?>
                    <div id="error-message" data-message="<?= $alert; ?>"></div>
                <?php endif; ?>

                <button type="submit" class="submit-button">Se connecter </button>
            </form>

            <p>Vous n'avez pas de compte ?<a href="<?= base_url('afficher/creation'); ?>"> Créer un compte</a></p>
        </div>
    </main>

    <!-- Fond sombre pour la popup -->
    <div id="overlay" class="overlay"></div>

    <!-- Popup pour afficher les erreurs -->
    <div id="popup" class="popup">
        <div class="popup-header">Erreur</div>
        <p id="popup-message" class="popup-message"></p>
        <button class="close-btn" onclick="closePopup()">Fermer</button>
    </div>

    <!-- Pied de page -->
    <footer class="footer">
        <p>&copy; 2024 Sport Zone. Tous droits réservés.</p>
    </footer>

    <!-- Script JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const errorMessage = document.getElementById('error-message');
            const popup = document.getElementById('popup');
            const popupMessage = document.getElementById('popup-message');
            const overlay = document.getElementById('overlay');

            if (errorMessage && errorMessage.dataset.message) {
                popupMessage.textContent = errorMessage.dataset.message;
                popup.classList.add('show');
                overlay.classList.add('show');
            }
        });

        function closePopup() {
            const popup = document.getElementById('popup');
            const overlay = document.getElementById('overlay');
            popup.classList.remove('show');
            overlay.classList.remove('show');
        }
    </script>
</body>
</html>