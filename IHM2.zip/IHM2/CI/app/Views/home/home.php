<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sport Zone</title>
    <link rel="stylesheet" href="public/CSS/style_page.css">
</head>
<body>
    <!-- En-tête -->
    <header class="animate-header">
        <h1>Sport Zone</h1>
        <a href="afficher/connexion" class="login-link">Connexion</a>
    </header>

    <!-- Navigation -->
    <nav class="main-nav">
        <a href="#intro" class="nav-link">Introduction</a>
        <a href="#sports" class="nav-link">Sports</a>
        <a href="#contact" class="nav-link">Contact</a>
    </nav>

    <!-- Contenu principal -->
    <main>
        <!-- Introduction -->
        <section id="intro" class="hero-section">
            <div class="hero-text">
                <h2>Améliorez vos Performances</h2>
                <p>Bienvenue sur Sport Zone, votre plateforme dédiée au suivi et à l'analyse de vos activités sportives.</p>
                <a href="afficher/connexion" class="cta-button">Commencer</a>
            </div>
            <img src="public/images/Sport_Zone_1.webp" alt="Sport Zone" class="hero-image">
        </section>

        <!-- Carrousel des sports -->
        <section id="sports" class="sports-section">
            <h2 class="section-title">Nos Sports</h2>
            <div class="carousel-container">
                <!-- Bouton précédent -->
                <button id="prev-btn" class="carousel-btn">&laquo;</button>
                <div class="sports-list">
                    <div class="sport-item">
                        <img src="public/images/course_Pied_IA.webp" alt="Course à pied" class="sport-image">
                        <div class="sport-description">
                            <h3>Course à Pied</h3>
                            <p>La course à pied est une activité idéale pour améliorer votre endurance et votre santé cardiovasculaire. Avec Sport Zone, suivez votre distance parcourue, votre rythme, votre vitesse moyenne et vos calories brûlées. Que vous soyez débutant ou expérimenté, notre application vous aide à fixer des objectifs réalistes et à atteindre vos nouveaux records personnels.</p>
                        </div>
                    </div>

                    <div class="sport-item">
                        <img src="public/images/marche_IA.webp" alt="Marche" class="sport-image">
                        <div class="sport-description">
                            <h3>Marche</h3>
                            <p>La marche, qu'elle soit sportive ou en randonnée, est une excellente activité pour maintenir une bonne santé et explorer de nouveaux horizons. Sport Zone permet de mesurer vos pas, votre vitesse et vos calories dépensées, tout en suivant vos progrès au fil du temps.</p>
                        </div>
                    </div>

                    <div class="sport-item">
                        <img src="public/images/natation_IA_3.webp" alt="Natation" class="sport-image">
                        <div class="sport-description">
                            <h3>Natation</h3>
                            <p>La natation est un excellent moyen de renforcer vos muscles et votre système cardiovasculaire tout en minimisant l'impact sur vos articulations. Suivez votre distance, le nombre de longueurs et les calories brûlées avec Sport Zone, et améliorez vos performances dans l'eau.</p>
                        </div>
                    </div>

                    <div class="sport-item">
                        <img src="public/images/velo_IA_.webp" alt="Vélo" class="sport-image">
                        <div class="sport-description">
                            <h3>Vélo</h3>
                            <p>Le cyclisme est une activité parfaite pour explorer de nouveaux paysages tout en améliorant votre condition physique. Grâce à Sport Zone, mesurez vos kilomètres parcourus, votre vitesse, vos dénivelés, et suivez vos performances pour atteindre vos objectifs.</p>
                        </div>
                    </div>
                </div>
                <!-- Bouton suivant -->
                <button id="next-btn" class="carousel-btn">&raquo;</button>
            </div>
        </section>

        <!-- Contact -->
        <section id="contact" class="contact-section">
            <h2 class="section-title">Contactez-Nous</h2>
            <p>Email : <a href="mailto:support@sportzone.com">support@sportzone.com</a></p>
            <p>Téléphone : +33 1 23 45 67 89</p>
        </section>
    </main>

    <!-- Pied de page -->
    <footer>
        <p>&copy; 2024 Sport Zone. Tous droits réservés.</p>
    </footer>

    <!-- Lien vers le fichier JS -->
    <script src="public/JS/animations.js" defer></script>
</body>
</html>
