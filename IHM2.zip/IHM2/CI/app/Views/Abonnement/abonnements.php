<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Abonnements - Sport Zone</title>
    <link rel="stylesheet" href="<?= base_url('public/CSS/abonnements-style.css'); ?>">
</head>
<body>
    <!-- En-tête -->
    <header class="header">
        <h1>Mes Abonnements</h1>
        <nav class="nav-bar">
             <a href="<?= base_url('afficher/retour'); ?>" class="nav-link"><i class="fas fa-arrow-left"></i> Retour</a>
        </nav>
    </header>

    <!-- Contenu principal -->
    <main class="subscriptions-container">
        <section class="subscriptions-list">
            <h2>Liste des abonnements</h2>
            <ul id="subscriptions">
    <!-- Afficher les abonnements -->
                <?php
                    if (!empty($pseudo) && is_array($pseudo)) {
                        foreach ($pseudo as $actu) { ?>
                            <li>
                                <div class="subscription-item">
                                    <img src="<?= base_url('public/images/AS.webp') ?>" alt="Profil" class="profile-pic">
                                    <div class="user-info">
                                        <h3><?= htmlspecialchars($actu['cpt_pseudo']); ?></h3>
                                        <p>Email : <?= htmlspecialchars($actu['cpt_login']); ?></p>
                                    </div>
                                    <button class="unsubscribe-btn" onclick="unsubscribe('<?= htmlspecialchars($actu['cpt_pseudo']) ?>')">Se désabonner</button>
                                </div>
                            </li>
                        <?php
                        }
                    } else { ?>
                        <li class="no-subscription">
                            <p>Aucun abonnement trouvé. Abonnez-vous maintenant !</p>
                        </li>
                    <?php
                    }
                ?>
            </ul>

        </section>
    </main>





    <!-- Pied de page -->
    <footer class="footer">
        <p>&copy; 2024 Sport Zone. Tous droits réservés.</p>
    </footer>

    <script src="<?= base_url('public/JS/abonnements.js'); ?>"></script>
</body>
</html>
