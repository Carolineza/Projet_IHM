<?php
namespace App\Models;
use CodeIgniter\Model;


class Db_model extends Model
{
    protected $db;
    public function __construct()
    {
    $this->db = db_connect(); //charger la base de données
    // ou
    // $this->db = \Config\Database::connect();
    }
    

    public function connect_compte($u, $p)
{
    // Adaptation de la requête à la nouvelle structure de la table
    $sql = ("SELECT `cpt_login`, `cpt_mot_passe` FROM `t_compte_cpt` WHERE `cpt_etat` = 'A' AND `cpt_login` = '" . $u . "' AND `cpt_mot_passe` = '" . $p . "';");
    
    $resultat = $this->db->query($sql);
    
    if ($resultat->getNumRows() > 0) {
        return true;
    } else {
        return false;
    }
}


public function inscrire_utilisateur($u, $email, $p)
{
    // Utilisation d'une requête préparée pour éviter les injections SQL
    $mail = htmlspecialchars(addslashes($email));
    $pseudo = htmlspecialchars(addslashes($u));
    $mot = htmlspecialchars(addslashes($p));

    // Vérifier si l'email ou le pseudo existent déjà
    $check_email = $this->db->query("SELECT COUNT(*) as count FROM t_compte_cpt WHERE cpt_login = '$mail'")->getRow();
    $check_pseudo = $this->db->query("SELECT COUNT(*) as count FROM t_compte_cpt WHERE cpt_pseudo = '$pseudo'")->getRow();

    if ($check_email->count > 0) {
        // L'email existe déjà, retourner false
        return 'Email déjà utilisé. Veuillez en choisir un autre.';
    }

    if ($check_pseudo->count > 0) {
        // Le pseudo existe déjà, retourner false
        return 'Ce pseudo est déjà pris. Veuillez en choisir un autre.';
    }

    // Si l'email et le pseudo sont uniques, procéder à l'insertion
    $sql = "INSERT INTO t_compte_cpt (cpt_pseudo, cpt_login, cpt_mot_passe, cpt_etat) VALUES ('".$pseudo."','".$mail."' , '".$mot."', 'A')";

    // Exécution de la requête
    if ($this->db->query($sql)) {
        // Si la requête réussit, retourner true ou un autre statut
        return true;
    } else {
        // Si la requête échoue, retourner false
        return 'Une erreur est survenue lors de l\'inscription. Veuillez réessayer.';
    }
}

public function get_pseudo($u)
    {
    
    $requete="SELECT `cpt_pseudo` FROM `t_compte_cpt`  WHERE `cpt_login`='".$u."';";
    $resultat = $this->db->query($requete);
    return $resultat->getRow();
    }




    public function get_all_actualites($u)
    {
    $resultat = $this->db->query("SELECT 
    att_id, att_nom, att_date, att_calories, att_visibilite, att_duree, att_distance 
    FROM 
        t_activite_att 
    WHERE 
        att_compte_id =".$u.";");
    return $resultat->getResultArray();
    }


// Permet de récupérer le id 
 public function get_role($u)
 {
 $requete="SELECT `cpt_id` FROM `t_compte_cpt`  WHERE `cpt_login` ='".$u."' OR `cpt_pseudo`='".$u."' ;";
 $resultat = $this->db->query($requete);
    $row = $resultat->getRow();
    
    // Vérifier si une ligne a été retournée
    if ($row) {
        // Récupérer la valeur de la colonne cpt_id et la convertir en entier
        $cpt_id = (int) $row->cpt_id;
        return $cpt_id;
    } else {
        // Gérer le cas où aucun résultat n'est retourné
        return null; // Ou toute autre valeur par défaut que vous souhaitez retourner
    }
 }

 public function save_activity($id, $saisie) {
    // Préparation de la requête SQL avec des paramètres pour éviter les injections SQL
       $nom = htmlspecialchars(addslashes($saisie['activity-name']));
       $visibilite =htmlspecialchars(addslashes($saisie['activity-day']));
       $duree = htmlspecialchars(addslashes($saisie['duration']));
       $distance =  htmlspecialchars(addslashes($saisie['distance']));
       $calorie =  htmlspecialchars(addslashes($saisie['calories']));
       $date =  htmlspecialchars(addslashes($saisie['start-time']));

     
     $sql="INSERT INTO `t_activite_att` VALUES (NULL, '.$id.', '".$nom."', '".$date."', '.$calorie.', '".$visibilite."', '".$duree."', '.$distance.');";
    // Préparer la requête
    return $this->db->query($sql);

    // Exécution de la requête
    
}

public function get_abomment($u)
{
$requete="SELECT COUNT(`abb_cible_id`) AS nb FROM `t_abonnement_abb` WHERE `abb_cible_id`=".$u.";";
$resultat = $this->db->query($requete);
return $resultat->getRow();
   
   // Vérifier si une ligne a été retournée
  
}

public function get_abonne($u)
{
$requete="SELECT COUNT(`abb_abonne_id`) AS nb FROM `t_abonnement_abb` WHERE `abb_abonne_id`=".$u.";";
$resultat = $this->db->query($requete);
 return $resultat->getRow();

}

public function get_inviteur($u)
{
$requete="SELECT `t_compte_cpt`.`cpt_pseudo` 
FROM `t_compte_cpt` 
JOIN `t_invitation_inv` 
ON `t_compte_cpt`.`cpt_id` = `t_invitation_inv`.`inviteur_id`
WHERE `t_invitation_inv`.`invite_id`=".$u.";";

$resultat = $this->db->query($requete);
return $resultat->getResultArray();

}

public function is_valid_friend($u, $id)
{
    // Vérifie d'abord si l'invitation existe déjà
    $checkQuery = "SELECT COUNT(`inv_id`) AS nb_inv FROM `t_invitation_inv` WHERE `inviteur_id` = ? AND `invite_id` = ?";
    $result = $this->db->query($checkQuery, [$u, $id]);

    $checkQuery2 = "SELECT COUNT(`abb_id`) AS nb FROM t_abonnement_abb WHERE `abb_abonne_id` = ? AND `abb_cible_id` = ?";
    $result2 = $this->db->query($checkQuery2, [$u, $id]);
    $row = $result2->getRow();

    if ((int) $row->nb > 0) {
        // Already an existing subscription
        return false;
    }

    // Vérifie si l'invitation n'existe pas avant d'insérer
    $row = $result->getRow();
    if ((int) $row->nb_inv > 0) {
        // Invitation already exists
        return false;
    }

    // Si l'invitation n'existe pas, insérez une nouvelle
    $insertQuery = "INSERT INTO `t_invitation_inv` (`inv_id`, `inviteur_id`, `invite_id`, `date_invitation`) 
                    VALUES (NULL, ?, ?, CURRENT_TIMESTAMP)";
    
    try {
        // Attempt to insert the invitation
        $this->db->query($insertQuery, [$u, $id]);
        return true;
    } catch (\CodeIgniter\Database\Exceptions\DatabaseException $e) {
        // Catch the database exception for duplicate entry
        if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
            // Handle duplicate entry error (for 'relation_unique' constraint)
            return false;
        }
        // Re-throw the exception if it's not a duplicate entry issue
        throw $e;
    }
}

public function is_a($u, $id)
{
   


    // Si l'invitation n'existe pas, insérez une nouvelle
    $insertQuery = "DELETE FROM t_invitation_inv WHERE `t_invitation_inv`.`inviteur_id`= ? AND `t_invitation_inv`.`invite_id`= ? ";
    
    $insertQuery2 = "INSERT INTO `t_abonnement_abb` (`abb_id`, `abb_abonne_id`, `abb_cible_id`, `abb_date_creation`) VALUES (NULL, ?, ?, CURRENT_TIMESTAMP); ";
    try {
        // Attempt to insert the invitation
        $this->db->query($insertQuery, [$id, $u]);
        $this->db->query($insertQuery2, [$u, $id]);
        return true;
    } catch (\CodeIgniter\Database\Exceptions\DatabaseException $e) {
        // Catch the database exception for duplicate entry
        if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
            // Handle duplicate entry error (for 'relation_unique' constraint)
            return false;
        }
        // Re-throw the exception if it's not a duplicate entry issue
        throw $e;
    }
}

public function is_r($u, $id)
{
   


    // Si l'invitation n'existe pas, insérez une nouvelle
    $insertQuery = "DELETE FROM t_invitation_inv WHERE `t_invitation_inv`.`inviteur_id`= ? AND `t_invitation_inv`.`invite_id`= ? ";
    

    try {
        // Attempt to insert the invitation
        $this->db->query($insertQuery, [$id, $u]);
        return true;
    } catch (\CodeIgniter\Database\Exceptions\DatabaseException $e) {
        // Catch the database exception for duplicate entry
        if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
            // Handle duplicate entry error (for 'relation_unique' constraint)
            return false;
        }
        // Re-throw the exception if it's not a duplicate entry issue
        throw $e;
    }
}





public function get_semaine($u)
{
        $requete="SELECT 
            SUM(`att_calories`) AS calorie, 
            SUM(`att_distance`) AS distance, 
            COUNT(`att_id`) AS nb 
        FROM 
            `t_activite_att` 
        WHERE 
            YEARWEEK(`att_date`, 1) = YEARWEEK(CURDATE(), 1) AND `att_compte_id`=".$u.";";
        $resultat = $this->db->query($requete);
        return $resultat->getRow();
   
   // Vérifier si une ligne a été retournée
  
}



// *************************************************** recupre get_jour ***********************************************


public function get_jour($u, $jour)
{
    $requete = "
        SELECT 
            IFNULL(SUM(`att_calories`), 0) AS calorie
        FROM 
            `t_activite_att` 
        WHERE 
            YEARWEEK(`att_date`, 1) = YEARWEEK(CURDATE(), 1)
            AND DAYOFWEEK(`att_date`) = ".$jour."
            AND `att_compte_id` = ".$u.";
    ";

    $resultat = $this->db->query($requete);

    if ($row = $resultat->getRow()) {
        return $row; // Renvoie l'objet avec la propriété 'calorie'
    } else {
        return (object) ['calorie' => 0]; // Renvoie un objet avec calorie = 0
    }
}

//****************************************************************************************************************************


//************************************************** abonnements **************************************************************************
public function get_abonnements($u)
{
    $requete="SELECT `t_compte_cpt`.`cpt_pseudo`, `t_compte_cpt`.`cpt_login`
    FROM `t_compte_cpt` 
    JOIN `t_abonnement_abb` 
    ON `t_compte_cpt`.`cpt_id` = `t_abonnement_abb`.`abb_abonne_id`
    WHERE `t_abonnement_abb`.`abb_cible_id`=".$u.";";

$resultat = $this->db->query($requete);
return $resultat->getResultArray();

}

   
}

