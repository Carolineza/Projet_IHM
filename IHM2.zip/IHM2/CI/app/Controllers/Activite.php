<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Activite extends BaseController
{

public function afficher() {
     

    $session=session();
    if ($session->has('user')){

     $model = model(Db_model::class);

     $pseudo=$session->get('user');
     $id = $model->get_role($pseudo);
     $data['new'] = $model->get_all_actualites($id);
     $data['pseudo']=$pseudo;

     return view('activite/activite.php',$data);
     

    }else{
       return redirect()->to(base_url('/'));
    }
     
}


public function retour() {
     

    $session=session();
    if ($session->has('user')){

     $model = model(Db_model::class);
     $email = $session->get('user');
     $id = $model->get_role($email);
     $session->set('id', $id);
     $data['pseudo'] = $model->get_pseudo($email);
     $data['abonne']= $model->get_abonne($id);
     $data['cible']= $model->get_abomment($id);
     $data['invites'] = $model->get_inviteur($id);
     return  view('activite/premiere_page.php',$data);
    }else{
       return redirect()->to(base_url('/'));
    }
     
}



public function ajoute() {
     

    $session=session();
    if ($session->has('user')){

     $model = model(Db_model::class);
      
     $method = $this->request->getMethod(true);

    
     if ($method === "POST") {
        // Récupération de l'ID de l'utilisateur connecté
        $login=$session->get('user');
        $id=$model->get_role($login);
        // Récupération des données postées dans un tableau
       
        $recuperation = $this->request->getPost();
    
        
        
        // Sauvegarde des données dans la base
    
            $result = $this->model->save_activity($id,$recuperation);  // Ajouter l'ID de l'utilisateur pour l'association
                
            
            if ($result) {
                // Succès : on redirige avec un message de succès
                session()->setFlashdata('success_message', 'L\'activité a été ajoutée avec succès.');
                return redirect()->to('activite/ajoute');
            } else {
                // Échec de la sauvegarde : on redirige avec un message d'erreur
                session()->setFlashdata('error_message', 'Une erreur est survenue lors de l\'ajout de l\'activité.');
                return redirect()->to('activite/ajoute');
            }
    }
    
    
     return  view('activite/ajoute_activite.php');
    }else{
       return redirect()->to(base_url('/'));
    }
     
}


public function deconnecter(){
$session=session();
$session->destroy();
 return redirect()->to(base_url('/'));
}
public function __construct()
{
    helper('form');
    $this->model = model(Db_model::class);
}




}

?>