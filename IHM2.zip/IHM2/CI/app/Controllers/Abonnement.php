<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Abonnement extends BaseController
{

public function afficher() {
     
    $session=session();
    if ($session->has('user')){

     $model = model(Db_model::class);
     $email = $session->get('user');
     $id = $model->get_role($email);
     $data['pseudo'] = $model->get_abonnements($id);
     return view('Abonnement/abonnements.php',$data);
    }else{
        return redirect()->to(base_url('/'));
     }
}

}
