document.addEventListener("DOMContentLoaded", function () {
    const faders = document.querySelectorAll(".fade-in");

    function checkVisibility() {
        const triggerBottom = window.innerHeight * 0.85;

        faders.forEach(fader => {
            const faderTop = fader.getBoundingClientRect().top;

            if (faderTop < triggerBottom) {
                fader.classList.add("active");
            } else {
                fader.classList.remove("active");
            }
        });
    }

    window.addEventListener("scroll", checkVisibility);
    checkVisibility(); // Initial check
});
