document.addEventListener("DOMContentLoaded", () => {
    const days = document.querySelectorAll(".day-circle");

    days.forEach((day) => {
        day.addEventListener("click", () => {
            // Retirer la classe active des autres jours
            days.forEach((d) => d.classList.remove("active"));

            // Ajouter la classe active au jour sélectionné
            day.classList.add("active");

            // Mettre à jour la date sélectionnée
            const selectedDate = document.getElementById("selected-date");
            selectedDate.textContent = `Statistiques pour : ${day.getAttribute("data-day")}`;
        });
    });
});
