// Gestion du changement de sport sélectionné
const sportButtons = document.querySelectorAll(".sport-btn");
const selectedSportDisplay = document.getElementById("selected-sport");

// Met à jour l'affichage en fonction du sport sélectionné
sportButtons.forEach((button) => {
    button.addEventListener("click", () => {
        const sportName = button.getAttribute("data-sport");
        const sportIcon = button.querySelector("img").src;

        // Enregistrer le sport dans localStorage
        localStorage.setItem("selectedSport", JSON.stringify({ name: sportName, icon: sportIcon }));

        // Rediriger vers la page activité
        window.location.href = "activite.html";
    });
});
// Affiche la section d'actions en fonction du sport sélectionné
function showActionsSection(sportName) {
    const welcomeBanner = document.querySelector(".welcome-banner");
    const actionsSection = document.querySelector(".actions-section");
    welcomeBanner.style.display = "block";
    actionsSection.style.display = "block";
    const sportIndicator = document.getElementById("selected-sport");
    sportIndicator.textContent = `Sport sélectionné : ${sportName}`;
}

// Redirection vers une page spécifique
function redirectToForm(page) {
    window.location.href = page;
}


// Gestion de la recherche d'amis
function searchFriends() {
    const searchInput = document.getElementById("search-friends").value.trim();
    if (searchInput) {
        alert(`Vous avez recherché : ${searchInput}`);
        // Logique supplémentaire : Rechercher dans une base de données ou une API
    } else {
        alert("Veuillez entrer un nom à rechercher !");
    }
}

// Gestion de l'affichage des demandes d'abonnement (invités)
const invitesList = document.getElementById("invites-list");
const exampleInvites = [
    { name: "Jean Dupont", id: 1 },
    { name: "Marie Curie", id: 2 },
    { name: "Albert Einstein", id: 3 }
];

// Afficher les invités
function displayInvites() {
    invitesList.innerHTML = "";
    exampleInvites.forEach((invite) => {
        const listItem = document.createElement("li");
        listItem.innerHTML = `
            <span>${invite.name}</span>
            <button onclick="acceptInvite(${invite.id})">Accepter</button>
            <button onclick="declineInvite(${invite.id})">Refuser</button>
        `;
        invitesList.appendChild(listItem);
    });
}

// Accepter une demande d'abonnement
function acceptInvite(id) {
    const invite = exampleInvites.find((inv) => inv.id === id);
    alert(`${invite.name} a été accepté(e) !`);
    // Logique pour mettre à jour les abonnements
}

// Refuser une demande d'abonnement
function declineInvite(id) {
    const invite = exampleInvites.find((inv) => inv.id === id);
    alert(`${invite.name} a été refusé(e).`);
    // Logique pour supprimer la demande
}



// Initialiser l'affichage des invités
displayInvites();
